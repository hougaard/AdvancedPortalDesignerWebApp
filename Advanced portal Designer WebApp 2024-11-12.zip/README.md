# AdvancedPortalDesignerWebApp
 Dotnet Core web app for Advanced Portal Designer
